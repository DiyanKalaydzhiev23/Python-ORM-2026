from django.db.models import Manager, Count

from querysets import RealEstateListingQuerySet


class RealEstateListingManager(Manager.from_queryset(RealEstateListingQuerySet)):
    def popular_locations(self) -> dict:
        """
        SELECT
            location,
            COUNT(location) AS location_count
        FROM
            real_estate_listing
        GROUP BY
            location
        ORDER BY
            location_count DESC,
            location ASC
        LIMIT 2;
        """
        return self.values('location').annotate(
            location_count=Count('location')
        ).order_by('-location_count', 'location')[:2]
